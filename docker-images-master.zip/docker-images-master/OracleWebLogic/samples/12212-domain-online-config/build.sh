#!/bin/sh
docker build -t 12212-domain-online-config . 
